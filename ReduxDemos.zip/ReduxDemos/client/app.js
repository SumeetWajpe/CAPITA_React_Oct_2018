// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';

import MainComponent from "./components/main.component";
import PostsComponent from "./components/posts.component";
import UsersComponent from "./components/users.component";

var router = <Router history={browserHistory}>
                            <Route path="/" component={MainComponent}>
                                    <IndexRoute component={UsersComponent}/>
                                    <Route path="/posts" component={PostsComponent}>
                                    </Route>
                            </Route>
                    </Router>


ReactDOM.render(router,document.getElementById('content'))