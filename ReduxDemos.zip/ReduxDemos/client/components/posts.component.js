import React from 'react';

export default class PostsComponent extends React.Component{
    render(){
        return <div>
                        <h1> Posts Component ! </h1>
                           
        </div> 
    }
}
